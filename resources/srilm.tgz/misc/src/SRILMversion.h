#define SRILM_RELEASE "1.6.0"
#define SRILM_COPYRIGHT "\n\
This software is subject to the SRILM Community Research License Version\n\
1.0 (the \"License\"); you may not use this software except in compliance\n\
with the License. A copy of the License is included in the SRILM root\n\
directory.  Software distributed under the License is distributed on an\n\
\"AS IS\" basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.\n\
See the License for the specific language governing rights and\n\
limitations under the License.  This software is Copyright (c) SRI\n\
International, 1995-2011.  All rights reserved.\n\
\n\
If this software was obtained under a commercial license agreement with\n\
SRI then the provisions therein govern the use of the software and the\n\
above notice does not apply.\n\
"
